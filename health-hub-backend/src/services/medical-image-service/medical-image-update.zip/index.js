const { uploadImage, analyzeImage } = require('./simple-medical-image');

module.exports = {
  uploadImage,
  analyzeImage
};
