const { transcribeAudio } = require('./simple-transcription');

module.exports = {
  transcribeAudio
};
